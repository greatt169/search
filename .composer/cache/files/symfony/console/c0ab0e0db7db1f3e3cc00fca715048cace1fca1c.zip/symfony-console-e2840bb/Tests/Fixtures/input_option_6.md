#### `--option_name|-o|-O`

option with multiple shortcuts

* Accept value: yes
* Is value required: yes
* Is multiple: no
* Default: `NULL`
